from flask import Flask, render_template, request, redirect, url_for, flash

app = Flask(__name__)
app.secret_key = 'sua_chave_secreta'

# Dicionário para armazenar os usuários registrados
users = {}
# Dicionário para armazenar os recursos
resources = {}

@app.route('/')
def home():
    return redirect(url_for('login'))

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        
        if username in users and users[username] == password:
            return redirect(url_for('dashboard'))  # Redireciona para o dashboard
        else:
            flash('Usuário ou senha inválidos!', 'error')
            return render_template('login.html')

    return render_template('login.html')

@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        
        if username in users:
            flash('Usuário já existe!', 'error')
            return render_template('register.html')

        users[username] = password
        return redirect(url_for('login'))
    return render_template('register.html')

@app.route('/dashboard')
def dashboard():
    return render_template('dashboard.html', resources=resources)

@app.route('/resources', methods=['GET', 'POST'])
def resources_management():
    if request.method == 'POST':
        action = request.form['action']
        resource_name = request.form['resource_name']
        
        if action == 'add':
            resources[resource_name] = request.form.get('resource_info', '')
            flash(f'Recurso "{resource_name}" adicionado com sucesso!')
        elif action == 'remove':
            if resource_name in resources:
                del resources[resource_name]
                flash(f'Recurso "{resource_name}" removido com sucesso!')
            else:
                flash(f'Recurso "{resource_name}" não encontrado!')
        elif action == 'update':
            new_info = request.form.get('resource_info', '')
            if resource_name in resources:
                resources[resource_name] = new_info
                flash(f'Recurso "{resource_name}" atualizado com sucesso!')
            else:
                flash(f'Recurso "{resource_name}" não encontrado!')
        
        return redirect(url_for('resources_management'))

    return render_template('resources.html', resources=resources)

if __name__ == '__main__':
    app.run(debug=True)


